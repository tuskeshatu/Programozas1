var structedge =
[
    [ "down", "structedge.html#a594cecf88b55c6f96b0fb277bd58e1f4", null ],
    [ "from", "structedge.html#ad3eb8a349ea9f7377a5424b25010d7b1", null ]
];