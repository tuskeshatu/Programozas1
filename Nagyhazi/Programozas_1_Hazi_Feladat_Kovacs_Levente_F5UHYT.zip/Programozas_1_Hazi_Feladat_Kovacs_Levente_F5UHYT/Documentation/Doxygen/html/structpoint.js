var structpoint =
[
    [ "dist", "structpoint.html#accf93555161c9eedf006462a228af523", null ],
    [ "edges_in", "structpoint.html#a008608f32b9f83b47ded9b43d6bff4af", null ],
    [ "id", "structpoint.html#a3670f4bed50c88882ceba330ffeb095c", null ],
    [ "itra", "structpoint.html#a8bc8844c4a53e08c58518895a243624d", null ],
    [ "location", "structpoint.html#a0411d69bda51bd8c227133e24084e1ab", null ],
    [ "visited", "structpoint.html#a4b66973fd0abdd396e7c9af5f52a9600", null ]
];