var searchData=
[
  ['debugmallocdata_0',['DebugmallocData',['../struct_debugmalloc_data.html',1,'']]],
  ['debugmallocentry_1',['DebugmallocEntry',['../struct_debugmalloc_entry.html',1,'']]],
  ['defining_20root_20and_20destination_20node_2',['Defining root and destination node',['../dev_guide.html#autotoc_md8',1,'']]],
  ['destination_20node_3',['Defining root and destination node',['../dev_guide.html#autotoc_md8',1,'']]],
  ['destroy_5fedges_4',['destroy_edges',['../itra__calc_8c.html#aece42006e59e830731fa49885f6f1202',1,'itra_calc.c']]],
  ['destroy_5fpoints_5',['destroy_points',['../itra__calc_8c.html#a777592a0ad74f6572c8f106ebad69025',1,'itra_calc.c']]],
  ['developer_20guide_6',['developer guide',['../dev_guide.html',1,'Developer guide'],['../index.html#autotoc_md18',1,'Developer guide']]],
  ['dijkstra_20algorithm_7',['The Dijkstra-algorithm',['../dev_guide.html#autotoc_md9',1,'']]],
  ['dist_8',['dist',['../structpoint.html#accf93555161c9eedf006462a228af523',1,'point']]],
  ['documentation_9',['documentation',['../index.html',1,'Documentation'],['../test_doc.html',1,'Testing documentation'],['../index.html#autotoc_md19',1,'Testing documentation']]],
  ['down_10',['down',['../structedge.html#a594cecf88b55c6f96b0fb277bd58e1f4',1,'edge']]]
];
