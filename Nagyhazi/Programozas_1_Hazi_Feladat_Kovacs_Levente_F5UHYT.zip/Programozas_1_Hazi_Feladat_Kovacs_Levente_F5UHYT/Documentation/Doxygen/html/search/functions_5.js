var searchData=
[
  ['improve_5fdist_0',['improve_dist',['../itra__calc_8c.html#a7858bc74bf482c2bbec69a07f2078439',1,'itra_calc.c']]],
  ['is_5fin_5flist_1',['is_in_list',['../itra__calc_8c.html#a4f9754bb75e2b21d82c88e4833e6c2ca',1,'itra_calc.c']]]
];
