var searchData=
[
  ['green_5fcolor_0',['GREEN_COLOR',['../itra__calc_8c.html#ac4bdeb73d33895bb745d17b3d8539a6a',1,'itra_calc.c']]]
];
