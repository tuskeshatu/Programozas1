var searchData=
[
  ['read_5fnodes_5ffrom_5froute_0',['read_nodes_from_route',['../itra__calc_8c.html#a41b2601c2b12d651a189170508c975a2',1,'itra_calc.c']]],
  ['read_5fpoints_1',['read_points',['../itra__calc_8c.html#af13812af799221713099f955dd7025f4',1,'itra_calc.c']]],
  ['reading_20points_20into_20a_20graph_2',['Reading points into a graph',['../dev_guide.html#autotoc_md4',1,'']]],
  ['representing_20a_20map_3',['Representing a map',['../dev_guide.html#autotoc_md0',1,'']]],
  ['reset_5fcolor_4',['RESET_COLOR',['../itra__calc_8c.html#ad7c3b975e5552a122f836b02fa138502',1,'itra_calc.c']]],
  ['results_5',['Output results',['../dev_guide.html#autotoc_md10',1,'']]],
  ['results_20of_20planning_6',['Results of planning',['../user_manual.html#autotoc_md36',1,'']]],
  ['root_20and_20destination_20node_7',['Defining root and destination node',['../dev_guide.html#autotoc_md8',1,'']]],
  ['route_20and_20track_20files_8',['Order of files or not matching route and track files',['../test_doc.html#autotoc_md25',1,'']]],
  ['route_20gpx_20files_9',['Route .gpx files',['../user_manual.html#autotoc_md31',1,'']]],
  ['route_20or_20track_20files_10',['Missing route or track files',['../test_doc.html#autotoc_md27',1,'']]],
  ['route_20type_20gpx_11',['Route type .gpx',['../dev_guide.html#autotoc_md2',1,'']]],
  ['running_20the_20program_12',['Running the program',['../user_manual.html#autotoc_md33',1,'']]]
];
