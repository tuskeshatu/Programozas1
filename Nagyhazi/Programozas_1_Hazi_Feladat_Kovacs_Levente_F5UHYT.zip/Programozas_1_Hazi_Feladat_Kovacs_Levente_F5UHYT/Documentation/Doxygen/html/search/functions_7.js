var searchData=
[
  ['nearest_5fpoint_0',['nearest_point',['../itra__calc_8c.html#a8e6ecd81efb77ff5f16afb571c452bed',1,'itra_calc.c']]]
];
