var searchData=
[
  ['destroy_5fedges_0',['destroy_edges',['../itra__calc_8c.html#aece42006e59e830731fa49885f6f1202',1,'itra_calc.c']]],
  ['destroy_5fpoints_1',['destroy_points',['../itra__calc_8c.html#a777592a0ad74f6572c8f106ebad69025',1,'itra_calc.c']]]
];
