var searchData=
[
  ['path_0',['path',['../test_doc.html#autotoc_md22',1,'Points far off the path'],['../test_doc.html#autotoc_md21',1,'Points near or on the path']]],
  ['path_20from_20start_20point_1',['Searching for shortest path from start point',['../dev_guide.html#autotoc_md7',1,'']]],
  ['phase_2',['Planning phase',['../dev_guide.html#autotoc_md12',1,'']]],
  ['planning_3',['planning',['../user_manual.html#autotoc_md36',1,'Results of planning'],['../user_manual.html#autotoc_md35',1,'Specifying start and end points for the planning']]],
  ['planning_20phase_4',['Planning phase',['../dev_guide.html#autotoc_md12',1,'']]],
  ['point_5',['point',['../structpoint.html',1,'point'],['../dev_guide.html#autotoc_md7',1,'Searching for shortest path from start point']]],
  ['point_5flist_6',['point_list',['../structpoint__list.html',1,'']]],
  ['points_20as_20nodes_7',['Storing points as nodes',['../dev_guide.html#autotoc_md5',1,'']]],
  ['points_20far_20off_20the_20path_8',['Points far off the path',['../test_doc.html#autotoc_md22',1,'']]],
  ['points_20for_20the_20planning_9',['Specifying start and end points for the planning',['../user_manual.html#autotoc_md35',1,'']]],
  ['points_20into_20a_20graph_10',['Reading points into a graph',['../dev_guide.html#autotoc_md4',1,'']]],
  ['points_20near_20or_20on_20the_20path_11',['Points near or on the path',['../test_doc.html#autotoc_md21',1,'']]],
  ['print_5froute_12',['print_route',['../itra__calc_8c.html#ae082408aa13c29b167bf25ad0f22dc40',1,'itra_calc.c']]],
  ['program_13',['Running the program',['../user_manual.html#autotoc_md33',1,'']]]
];
