var searchData=
[
  ['get_5felevation_0',['get_elevation',['../itra__calc_8c.html#a560f5c80548ae92bc99fc84f2401f4dc',1,'itra_calc.c']]],
  ['get_5flast_5fedge_1',['get_last_edge',['../itra__calc_8c.html#a2a4019289b0eb1ed9a96cec4b38bad0b',1,'itra_calc.c']]]
];
