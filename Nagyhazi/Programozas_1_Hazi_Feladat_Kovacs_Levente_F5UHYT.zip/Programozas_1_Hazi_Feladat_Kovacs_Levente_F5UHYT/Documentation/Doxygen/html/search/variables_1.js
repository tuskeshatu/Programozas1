var searchData=
[
  ['edges_5fin_0',['edges_in',['../structpoint.html#a008608f32b9f83b47ded9b43d6bff4af',1,'point']]]
];
