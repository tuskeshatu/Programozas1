var searchData=
[
  ['calculate_5fitra_0',['calculate_itra',['../itra__calc_8c.html#a627338ccb86565ad1fc4a7ad6d0c520e',1,'itra_calc.c']]],
  ['calculatedistance_1',['calculateDistance',['../itra__calc_8c.html#a02434d9cbacdb757bbce7d8d872bc5d8',1,'itra_calc.c']]],
  ['command_20line_20arguments_20input_20files_2',['Command line arguments - input files',['../test_doc.html#autotoc_md24',1,'']]],
  ['compiling_3',['Errors compiling',['../dev_guide.html#autotoc_md15',1,'']]],
  ['computing_20efficiency_4',['Computing efficiency',['../dev_guide.html#autotoc_md13',1,'']]],
  ['coordinate_20format_20error_5',['Coordinate format error',['../test_doc.html#autotoc_md28',1,'']]],
  ['coordinates_6',['coordinates',['../structcoordinates.html',1,'']]],
  ['corrupted_20files_7',['File errors, corrupted files',['../test_doc.html#autotoc_md29',1,'']]],
  ['count_5fpoints_8',['count_points',['../itra__calc_8c.html#ae9724035b23c8622a2a189d6161591bf',1,'itra_calc.c']]]
];
