var searchData=
[
  ['coordinates_0',['coordinates',['../structcoordinates.html',1,'']]]
];
