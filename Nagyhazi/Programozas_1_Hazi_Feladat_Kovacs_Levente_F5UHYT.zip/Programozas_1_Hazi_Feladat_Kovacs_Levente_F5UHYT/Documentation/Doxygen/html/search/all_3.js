var searchData=
[
  ['edge_0',['edge',['../structedge.html',1,'']]],
  ['edges_5fin_1',['edges_in',['../structpoint.html#a008608f32b9f83b47ded9b43d6bff4af',1,'point']]],
  ['edges_5flist_2',['edges_list',['../structedges__list.html',1,'']]],
  ['efficiency_3',['Computing efficiency',['../dev_guide.html#autotoc_md13',1,'']]],
  ['end_20points_20for_20the_20planning_4',['Specifying start and end points for the planning',['../user_manual.html#autotoc_md35',1,'']]],
  ['err_5fcolor_5',['ERR_COLOR',['../itra__calc_8c.html#a59be80d1d80fc8a9dbfe8d823dbbac74',1,'itra_calc.c']]],
  ['error_6',['Coordinate format error',['../test_doc.html#autotoc_md28',1,'']]],
  ['errors_7',['User input errors',['../test_doc.html#autotoc_md23',1,'']]],
  ['errors_20compiling_8',['Errors compiling',['../dev_guide.html#autotoc_md15',1,'']]],
  ['errors_20corrupted_20files_9',['File errors, corrupted files',['../test_doc.html#autotoc_md29',1,'']]],
  ['extension_10',['Missing file extension',['../test_doc.html#autotoc_md26',1,'']]]
];
