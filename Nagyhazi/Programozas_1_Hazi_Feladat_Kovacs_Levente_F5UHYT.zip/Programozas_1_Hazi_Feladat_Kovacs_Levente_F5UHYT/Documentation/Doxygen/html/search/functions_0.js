var searchData=
[
  ['add_5fedge_5fin_0',['add_edge_in',['../itra__calc_8c.html#a4e372ab720467c0b31df14394f5837b5',1,'itra_calc.c']]]
];
