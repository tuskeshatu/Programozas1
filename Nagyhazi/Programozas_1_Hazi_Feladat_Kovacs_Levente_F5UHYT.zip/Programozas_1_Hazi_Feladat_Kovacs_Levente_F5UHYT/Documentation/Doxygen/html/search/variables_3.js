var searchData=
[
  ['id_0',['id',['../structpoint.html#a3670f4bed50c88882ceba330ffeb095c',1,'point']]],
  ['itra_1',['itra',['../structpoint.html#a8bc8844c4a53e08c58518895a243624d',1,'point']]]
];
