var searchData=
[
  ['itra_5fcalc_2ec_0',['itra_calc.c',['../itra__calc_8c.html',1,'']]]
];
