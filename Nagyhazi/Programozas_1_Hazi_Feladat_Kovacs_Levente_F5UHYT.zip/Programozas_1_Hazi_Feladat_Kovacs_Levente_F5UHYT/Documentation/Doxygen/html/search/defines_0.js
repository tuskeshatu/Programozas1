var searchData=
[
  ['err_5fcolor_0',['ERR_COLOR',['../itra__calc_8c.html#a59be80d1d80fc8a9dbfe8d823dbbac74',1,'itra_calc.c']]]
];
