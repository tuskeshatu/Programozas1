var searchData=
[
  ['order_5flist_0',['order_list',['../itra__calc_8c.html#aa0a9220ddb43b425386a06c720d6b6e9',1,'itra_calc.c']]],
  ['order_5fmerged_5fedges_1',['order_merged_edges',['../itra__calc_8c.html#aa896a6f73226d761c0f2c4cf3f6b36fe',1,'itra_calc.c']]]
];
