var searchData=
[
  ['near_20or_20on_20the_20path_0',['Points near or on the path',['../test_doc.html#autotoc_md21',1,'']]],
  ['nearest_5fpoint_1',['nearest_point',['../itra__calc_8c.html#a8e6ecd81efb77ff5f16afb571c452bed',1,'itra_calc.c']]],
  ['node_2',['Defining root and destination node',['../dev_guide.html#autotoc_md8',1,'']]],
  ['nodes_3',['nodes',['../dev_guide.html#autotoc_md6',1,'Merging nodes'],['../dev_guide.html#autotoc_md5',1,'Storing points as nodes']]],
  ['not_20matching_20route_20and_20track_20files_4',['Order of files or not matching route and track files',['../test_doc.html#autotoc_md25',1,'']]]
];
