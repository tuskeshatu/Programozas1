var searchData=
[
  ['warn_5fcolor_0',['WARN_COLOR',['../itra__calc_8c.html#ade48c7e2e47b62c4ba5b651a8fce44d7',1,'itra_calc.c']]]
];
