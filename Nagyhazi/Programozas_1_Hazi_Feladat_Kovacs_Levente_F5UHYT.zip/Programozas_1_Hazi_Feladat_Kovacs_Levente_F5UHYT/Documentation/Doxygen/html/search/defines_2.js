var searchData=
[
  ['info_5fcolor_0',['INFO_COLOR',['../itra__calc_8c.html#a5d724ff30124b3ce91f377afb4598ed7',1,'itra_calc.c']]],
  ['input_5fcolor_1',['INPUT_COLOR',['../itra__calc_8c.html#aadb3e24b0191a3b06d8dfc41506a81dd',1,'itra_calc.c']]]
];
