var searchData=
[
  ['dist_0',['dist',['../structpoint.html#accf93555161c9eedf006462a228af523',1,'point']]],
  ['down_1',['down',['../structedge.html#a594cecf88b55c6f96b0fb277bd58e1f4',1,'edge']]]
];
