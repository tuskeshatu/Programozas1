var searchData=
[
  ['a_20graph_0',['Reading points into a graph',['../dev_guide.html#autotoc_md4',1,'']]],
  ['a_20map_1',['Representing a map',['../dev_guide.html#autotoc_md0',1,'']]],
  ['abstract_2',['Abstract',['../index.html#autotoc_md16',1,'']]],
  ['add_5fedge_5fin_3',['add_edge_in',['../itra__calc_8c.html#a4e372ab720467c0b31df14394f5837b5',1,'itra_calc.c']]],
  ['algorithm_4',['The Dijkstra-algorithm',['../dev_guide.html#autotoc_md9',1,'']]],
  ['and_20destination_20node_5',['Defining root and destination node',['../dev_guide.html#autotoc_md8',1,'']]],
  ['and_20end_20points_20for_20the_20planning_6',['Specifying start and end points for the planning',['../user_manual.html#autotoc_md35',1,'']]],
  ['and_20track_20files_7',['Order of files or not matching route and track files',['../test_doc.html#autotoc_md25',1,'']]],
  ['arguments_20input_20files_8',['Command line arguments - input files',['../test_doc.html#autotoc_md24',1,'']]],
  ['as_20nodes_9',['Storing points as nodes',['../dev_guide.html#autotoc_md5',1,'']]]
];
