var searchData=
[
  ['reset_5fcolor_0',['RESET_COLOR',['../itra__calc_8c.html#ad7c3b975e5552a122f836b02fa138502',1,'itra_calc.c']]]
];
