var searchData=
[
  ['id_0',['id',['../structpoint.html#a3670f4bed50c88882ceba330ffeb095c',1,'point']]],
  ['improve_5fdist_1',['improve_dist',['../itra__calc_8c.html#a7858bc74bf482c2bbec69a07f2078439',1,'itra_calc.c']]],
  ['info_5fcolor_2',['INFO_COLOR',['../itra__calc_8c.html#a5d724ff30124b3ce91f377afb4598ed7',1,'itra_calc.c']]],
  ['input_20errors_3',['User input errors',['../test_doc.html#autotoc_md23',1,'']]],
  ['input_20files_4',['input files',['../test_doc.html#autotoc_md24',1,'Command line arguments - input files'],['../user_manual.html#autotoc_md30',1,'Input files']]],
  ['input_5fcolor_5',['INPUT_COLOR',['../itra__calc_8c.html#aadb3e24b0191a3b06d8dfc41506a81dd',1,'itra_calc.c']]],
  ['into_20a_20graph_6',['Reading points into a graph',['../dev_guide.html#autotoc_md4',1,'']]],
  ['is_5fin_5flist_7',['is_in_list',['../itra__calc_8c.html#a4f9754bb75e2b21d82c88e4833e6c2ca',1,'itra_calc.c']]],
  ['itra_8',['itra',['../structpoint.html#a8bc8844c4a53e08c58518895a243624d',1,'point']]],
  ['itra_5fcalc_2ec_9',['itra_calc.c',['../itra__calc_8c.html',1,'']]]
];
