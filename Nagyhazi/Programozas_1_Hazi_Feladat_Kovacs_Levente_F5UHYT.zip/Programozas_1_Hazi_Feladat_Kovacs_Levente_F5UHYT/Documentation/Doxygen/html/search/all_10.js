var searchData=
[
  ['visited_0',['visited',['../structpoint.html#a4b66973fd0abdd396e7c9af5f52a9600',1,'point']]]
];
