var searchData=
[
  ['calculate_5fitra_0',['calculate_itra',['../itra__calc_8c.html#a627338ccb86565ad1fc4a7ad6d0c520e',1,'itra_calc.c']]],
  ['calculatedistance_1',['calculateDistance',['../itra__calc_8c.html#a02434d9cbacdb757bbce7d8d872bc5d8',1,'itra_calc.c']]],
  ['count_5fpoints_2',['count_points',['../itra__calc_8c.html#ae9724035b23c8622a2a189d6161591bf',1,'itra_calc.c']]]
];
