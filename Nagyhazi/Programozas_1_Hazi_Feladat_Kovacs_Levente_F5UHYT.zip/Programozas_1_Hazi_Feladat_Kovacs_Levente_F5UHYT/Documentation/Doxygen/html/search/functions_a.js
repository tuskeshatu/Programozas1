var searchData=
[
  ['read_5fnodes_5ffrom_5froute_0',['read_nodes_from_route',['../itra__calc_8c.html#a41b2601c2b12d651a189170508c975a2',1,'itra_calc.c']]],
  ['read_5fpoints_1',['read_points',['../itra__calc_8c.html#af13812af799221713099f955dd7025f4',1,'itra_calc.c']]]
];
