var searchData=
[
  ['get_5felevation_0',['get_elevation',['../itra__calc_8c.html#a560f5c80548ae92bc99fc84f2401f4dc',1,'itra_calc.c']]],
  ['get_5flast_5fedge_1',['get_last_edge',['../itra__calc_8c.html#a2a4019289b0eb1ed9a96cec4b38bad0b',1,'itra_calc.c']]],
  ['gpx_2',['gpx',['../dev_guide.html#autotoc_md2',1,'Route type .gpx'],['../dev_guide.html#autotoc_md3',1,'Track type .gpx']]],
  ['gpx_20files_3',['gpx files',['../dev_guide.html#autotoc_md1',1,'.gpx files'],['../user_manual.html#autotoc_md31',1,'Route .gpx files'],['../user_manual.html#autotoc_md32',1,'Track .gpx files']]],
  ['graph_4',['Reading points into a graph',['../dev_guide.html#autotoc_md4',1,'']]],
  ['green_5fcolor_5',['GREEN_COLOR',['../itra__calc_8c.html#ac4bdeb73d33895bb745d17b3d8539a6a',1,'itra_calc.c']]],
  ['guide_6',['guide',['../dev_guide.html',1,'Developer guide'],['../index.html#autotoc_md18',1,'Developer guide']]]
];
