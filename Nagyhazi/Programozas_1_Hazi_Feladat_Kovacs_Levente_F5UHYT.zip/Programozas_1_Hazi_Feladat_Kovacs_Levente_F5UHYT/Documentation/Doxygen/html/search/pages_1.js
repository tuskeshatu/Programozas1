var searchData=
[
  ['guide_0',['Developer guide',['../dev_guide.html',1,'index']]]
];
