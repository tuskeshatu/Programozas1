var searchData=
[
  ['location_0',['location',['../structpoint.html#a0411d69bda51bd8c227133e24084e1ab',1,'point']]]
];
