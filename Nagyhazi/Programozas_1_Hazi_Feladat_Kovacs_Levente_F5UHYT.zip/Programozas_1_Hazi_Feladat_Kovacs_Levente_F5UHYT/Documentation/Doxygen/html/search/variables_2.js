var searchData=
[
  ['from_0',['from',['../structedge.html#ad3eb8a349ea9f7377a5424b25010d7b1',1,'edge']]]
];
