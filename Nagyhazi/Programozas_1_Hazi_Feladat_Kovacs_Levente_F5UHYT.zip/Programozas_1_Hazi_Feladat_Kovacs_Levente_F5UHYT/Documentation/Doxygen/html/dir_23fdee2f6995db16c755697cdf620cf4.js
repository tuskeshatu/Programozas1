var dir_23fdee2f6995db16c755697cdf620cf4 =
[
    [ "debugmalloc.h", "debugmalloc_8h_source.html", null ],
    [ "itra_calc.c", "itra__calc_8c.html", "itra__calc_8c" ]
];